﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("dhtmlxConnector.Net Samples")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DHTMLX LTD.")]
[assembly: AssemblyProduct("dhtmlxConnectors.NET Samples")]
[assembly: AssemblyCopyright("Copyright © DHTMLX LTD. 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("3d5900ae-111a-45be-96b3-d9e4606ca793")]

[assembly: AssemblyVersion("0.9.8.3")]
[assembly: AssemblyFileVersion("0.9.8.3")]
