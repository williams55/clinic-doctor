dhtmlxConnector for .Net v.1.0b build 110725

This software is a beta version.
If You had discover any bugs or have some ideas, how it can be 
improved - contact us at support@dhtmlx.com


dhtmlxConnectors.NET are built using Microsoft .NET Framework 3.5


IMPORTANT: 
	Samples project is using Standard version of dhtmlx components, 
	which allows to use all functionality except of TreeGrid. 
	If you want to use PRO version of components, just replace 
	"samples/dhtmlx/dhtmlx.js" with related file from PRO package

(c) DHTMLX Ltd. 