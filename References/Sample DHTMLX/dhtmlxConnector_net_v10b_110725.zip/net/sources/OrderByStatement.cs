﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Represents single ORDER BY construct element
    /// </summary>
    public abstract class OrderByStatement
    {
    }
}
