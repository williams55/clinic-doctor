﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("dhtmlxConnectors.NET")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DHTMLX LTD.")]
[assembly: AssemblyProduct("dhtmlxConnectors.NET")]
[assembly: AssemblyCopyright("Copyright © DHTMLX LTD. 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("55b51cd1-8d7e-4893-aa62-cceed76ef850")]

[assembly: AssemblyVersion("0.9.8.3")]
[assembly: AssemblyFileVersion("0.9.8.3")]
