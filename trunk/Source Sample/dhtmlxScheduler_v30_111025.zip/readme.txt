dhtmlxScheduler v.3.0 build 110727

This software is allowed to use under GPL or you need to obtain Commercial or Enterise License
to use it in non-GPL project. Please contact sales@dhtmlx.com for details

(c) DHTMLX Ltd. 