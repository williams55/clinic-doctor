<?php
	$server = "localhost";
	$user	= "root";
	$pass	= "";
	$db_name= "sampleDB";
?>